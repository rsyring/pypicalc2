from __future__ import unicode_literals

VERSION = '0.2.dev1'
